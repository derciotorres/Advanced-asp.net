﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Practice.Models;
using Practice.ViewModels.Home;
using System.Web.Helpers;

namespace Practice.Controllers
{
    public class ArtistsController : Controller
    {
        private ArtistDb Db = new ArtistDb();
        // GET: Artists


        public ActionResult ArtistList()
        {


            var artistdata = new ArtistDb();


            var viewModel = new ArtistListViewModel(artistdata.Artists);

            return View(viewModel);
        }
        public ActionResult listofArtists(string searchCriteria)
        {
            /*
            var artistdata = new ArtistDb();

        var artists = new ArtistDb().Artists.ToList();
            return View(artists);
            */

            var artistdata = new ArtistDb();

            IQueryable<Artist> artists = artistdata.Artists.OrderBy(p => p.ArtistName);

            if(searchCriteria != null)
                {

                artists = artists.Where(p => p.ArtistName.Contains(searchCriteria));
         
            }
            var artistList1 = artists.Take(2).ToList();
            return View(artistList1);

        }

        public ActionResult Details (int id)
        {
            var artistdata = new ArtistDb();

            Artist found = artistdata.Artists.Where(p => p.Artist_Id == id).FirstOrDefault();

            return View(found);


        }
        public ActionResult Picture(int id)
        {
            var artistData = new ArtistDb();

            var artist = artistData.Artists.Where(p => p.Artist_Id == id).FirstOrDefault();

            if (artist == null)

            {
                return HttpNotFound();

            }

            var img = new WebImage(string.Format("~/Content/Images/{0}.jpg", artist.ImageName));
            img.Resize(100, 100);


            return File(img.GetBytes(), "image/jpeg");

        }

    }
}