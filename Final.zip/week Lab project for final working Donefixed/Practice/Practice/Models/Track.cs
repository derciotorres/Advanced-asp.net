﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Practice.Models
{
    public class Track
    {

        [Key]
        public int Track_Id { get; set; }
        public string group { get; set; }
        public string Track1 { get; set; }
        public string Track1Time { get; set; }

        public string Track2 { get; set; }
        public string Track2Time { get; set; }
        public string Track3 { get; set; }
        public string Track3Time { get; set; }
        public string Track4 { get; set; }
        public string Track4Time { get; set; }
        public string Track5 { get; set; }
        public string Track5Time { get; set; }



        public virtual ICollection<Album> Album { get; set; }
    }
}