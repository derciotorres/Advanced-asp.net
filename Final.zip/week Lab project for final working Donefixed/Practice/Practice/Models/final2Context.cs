﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Practice.Models
{
    public class final2Context : DbContext
    {
        // You can add custom code to this file. Changes will not be overwritten.
        // 
        // If you want Entity Framework to drop and regenerate your database
        // automatically whenever you change your model schema, please use data migrations.
        // For more information refer to the documentation:
        // http://msdn.microsoft.com/en-us/data/jj591621.aspx
    
        public final2Context() : base("name=final2Context")
        {
        }

        public System.Data.Entity.DbSet<Practice.Models.Track> Tracks { get; set; }

        public System.Data.Entity.DbSet<Practice.Models.Album> Albums { get; set; }

        public System.Data.Entity.DbSet<Practice.Models.Artist> Artists { get; set; }
    }
}
