﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Practice.Models
{
    public class Album
    {
        [Key]
        public int Album_Id { get; set; }
        public string Album_Name { get; set; }
        public string Number_Tracks { get; set; }


        public string Album_Pic { get; set; }

        public virtual ICollection<Artist> Artists { get; set; }
        public int Track_Id { get; set; }

       public virtual Track Track { get; set; }
    }
}