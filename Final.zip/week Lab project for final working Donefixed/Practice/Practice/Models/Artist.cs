﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Practice.Models
{
    public class Artist
    {
        [Key]
        public int Artist_Id { get; set; }

        [Required(ErrorMessage = "Must fill up")]
        [RegularExpression("..+", ErrorMessage = "Must be at least 2 char long")]
        public string ArtistName { get; set; }
        [Required(ErrorMessage = "Must fill up")]
        [RegularExpression("..+", ErrorMessage = "Must be at least 2 char long")]
        public string Email { get; set; }
        public DateTime Date { get; set; }

        public string ImageName { get; set; }


        public int Album_Id { get; set; }

        public virtual Album album { get; set; }
    }
}